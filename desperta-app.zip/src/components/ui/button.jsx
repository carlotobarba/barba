
export const Button = ({ children, className = "", ...props }) => (
  <button className={`p-2 rounded text-white ${className}`} {...props}>
    {children}
  </button>
);
